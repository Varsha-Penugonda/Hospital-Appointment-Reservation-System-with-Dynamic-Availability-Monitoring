# Doctor Appointment Scheduler

A Spring Boot and Thymeleaf scheduling platform for patients and doctors. The project has been upgraded from a basic appointment demo into a richer hospital workflow with analytics, structured booking data, responsive dashboards, and seeded demo data.

## Highlights

- Modern landing page and responsive patient/doctor portals
- Rich doctor profiles with hospital, experience, fee, availability, modes, and bio
- Structured appointment booking with date, time slot, consultation mode, priority, and symptoms
- Appointment lifecycle states: requested, confirmed, completed, cancelled
- Patient dashboard with appointment analytics and recent activity
- Doctor workspace with queue metrics and one-click status actions
- H2 in-memory database with seeded demo accounts and appointments
- Repository-driven booking validation to prevent double-booking active slots

## Tech Stack

- Spring Boot
- Spring MVC
- Spring Data JPA
- Thymeleaf
- H2 Database
- Maven

## Demo Access

- Patient:
  - Email: `alex.carter@mednova.app`
  - Password: `patient123`
- Doctor:
  - Email: `dr.amelia@mednova.app`
  - Password: `doctor123`

## Run

```bash
bash mvnw spring-boot:run
```

Then open `http://localhost:8080`.

## Test

```bash
bash mvnw test
```

