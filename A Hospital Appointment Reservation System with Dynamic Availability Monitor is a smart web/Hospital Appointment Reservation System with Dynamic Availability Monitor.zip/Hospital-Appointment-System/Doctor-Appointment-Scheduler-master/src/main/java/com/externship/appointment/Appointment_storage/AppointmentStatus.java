package com.externship.appointment.Appointment_storage;

public enum AppointmentStatus {
	REQUESTED("Requested"),
	CONFIRMED("Confirmed"),
	COMPLETED("Completed"),
	CANCELLED("Cancelled");

	private final String label;

	AppointmentStatus(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}

	public static AppointmentStatus from(String value) {
		return AppointmentStatus.valueOf(value.trim().toUpperCase());
	}

	@Override
	public String toString() {
		return label;
	}
}
