package com.externship.appointment.Doctor_storage;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DoctorRepository extends JpaRepository<Doctor, String> {

	List<Doctor> findAllByOrderBySpecializationAscNameAsc();
}
