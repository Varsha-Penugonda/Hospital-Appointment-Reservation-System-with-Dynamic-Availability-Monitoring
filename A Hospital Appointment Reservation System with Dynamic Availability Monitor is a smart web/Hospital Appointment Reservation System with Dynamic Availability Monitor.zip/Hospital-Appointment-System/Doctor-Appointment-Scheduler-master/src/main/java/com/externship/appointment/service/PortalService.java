package com.externship.appointment.service;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.externship.appointment.Appointment_storage.Appointment;
import com.externship.appointment.Appointment_storage.AppointmentRepository;
import com.externship.appointment.Appointment_storage.AppointmentStatus;
import com.externship.appointment.Doctor_storage.Doctor;
import com.externship.appointment.Doctor_storage.DoctorRepository;
import com.externship.appointment.Person_storage.Person;
import com.externship.appointment.Person_storage.PersonRepository;

@Service
public class PortalService {

	private static final Set<AppointmentStatus> ACTIVE_STATUSES = EnumSet.of(
		AppointmentStatus.REQUESTED,
		AppointmentStatus.CONFIRMED
	);

	private final PersonRepository personRepository;
	private final DoctorRepository doctorRepository;
	private final AppointmentRepository appointmentRepository;

	public PortalService(
		PersonRepository personRepository,
		DoctorRepository doctorRepository,
		AppointmentRepository appointmentRepository
	) {
		this.personRepository = personRepository;
		this.doctorRepository = doctorRepository;
		this.appointmentRepository = appointmentRepository;
	}

	@Transactional
	public Person registerPatient(Person person) {
		person.setEmail(normalize(person.getEmail()));
		person.setFullName(defaultText(person.getFullName(), deriveNameFromEmail(person.getEmail())));
		person.setPhoneNumber(defaultText(person.getPhoneNumber(), "Not provided"));
		person.setCity(defaultText(person.getCity(), "Remote"));
		person.setPassword(defaultText(person.getPassword(), ""));
		return personRepository.save(person);
	}

	@Transactional
	public Doctor registerDoctor(Doctor doctor) {
		doctor.setEmail(normalize(doctor.getEmail()));
		doctor.setName(defaultText(doctor.getName(), deriveNameFromEmail(doctor.getEmail())));
		doctor.setSpecialization(defaultText(doctor.getSpecialization(), "General Medicine"));
		doctor.setDegree(defaultText(doctor.getDegree(), "MBBS"));
		doctor.setState(defaultText(doctor.getState(), "State not provided"));
		doctor.setCity(defaultText(doctor.getCity(), "City not provided"));
		doctor.setHospitalName(defaultText(doctor.getHospitalName(), "CityCare Medical Center"));
		doctor.setYearsOfExperience(doctor.getYearsOfExperience() == null ? 5 : doctor.getYearsOfExperience());
		doctor.setConsultationFee(doctor.getConsultationFee() == null ? BigDecimal.valueOf(700) : doctor.getConsultationFee());
		doctor.setAvailableDays(defaultText(doctor.getAvailableDays(), "Monday, Tuesday, Wednesday, Thursday, Friday"));
		doctor.setConsultationModes(defaultText(doctor.getConsultationModes(), "In Person, Virtual"));
		doctor.setBio(defaultText(
			doctor.getBio(),
			doctor.getName() + " is a " + doctor.getSpecialization() + " specialist focused on accessible, modern care."
		));
		doctor.setPassword(defaultText(doctor.getPassword(), ""));
		return doctorRepository.save(doctor);
	}

	public Optional<Person> authenticatePatient(String email, String password) {
		String normalizedEmail = normalize(email);
		return personRepository.findById(normalizedEmail)
			.filter(person -> person.getPassword().equals(password));
	}

	public Optional<Doctor> authenticateDoctor(String email, String password) {
		String normalizedEmail = normalize(email);
		return doctorRepository.findById(normalizedEmail)
			.filter(doctor -> doctor.getPassword().equals(password));
	}

	public Optional<Person> getPatient(String email) {
		return personRepository.findById(normalize(email));
	}

	public Optional<Doctor> getDoctor(String email) {
		return doctorRepository.findById(normalize(email));
	}

	public List<Doctor> getDoctors() {
		return doctorRepository.findAllByOrderBySpecializationAscNameAsc();
	}

	public List<Doctor> getFeaturedDoctors() {
		return getDoctors().stream()
			.sorted(Comparator.comparing(Doctor::getYearsOfExperience, Comparator.nullsLast(Comparator.reverseOrder()))
				.thenComparing(Doctor::getName, Comparator.nullsLast(String::compareToIgnoreCase)))
			.limit(4)
			.collect(Collectors.toList());
	}

	public List<String> getSpecializations() {
		return getDoctors().stream()
			.map(Doctor::getSpecialization)
			.filter(value -> value != null && !value.isBlank())
			.distinct()
			.collect(Collectors.toList());
	}

	public List<String> getCities() {
		return getDoctors().stream()
			.map(Doctor::getCity)
			.filter(value -> value != null && !value.isBlank())
			.distinct()
			.collect(Collectors.toList());
	}

	public List<Appointment> getPatientAppointments(String email) {
		return appointmentRepository.findAllByEmailOrderByDateAscTimeSlotAsc(normalize(email));
	}

	public List<Appointment> getDoctorAppointments(String email) {
		return appointmentRepository.findByDocIdOrderByDateAscTimeSlotAsc(normalize(email));
	}

	public Map<String, Long> buildPatientHomeStats(String email) {
		List<Appointment> appointments = getPatientAppointments(email);
		LocalDate today = LocalDate.now();

		Map<String, Long> stats = new LinkedHashMap<>();
		stats.put("totalAppointments", (long) appointments.size());
		stats.put("upcomingAppointments", countWhere(appointments,
			app -> isActive(app.getStatus()) && app.getDate() != null && !app.getDate().isBefore(today)));
		stats.put("confirmedAppointments", countWhere(appointments, app -> app.getStatus() == AppointmentStatus.CONFIRMED));
		stats.put("virtualAppointments", countWhere(appointments, app -> equalsIgnoreCase(app.getMode(), "Virtual")));
		return stats;
	}

	public Map<String, Long> buildPatientAppointmentStats(String email) {
		List<Appointment> appointments = getPatientAppointments(email);
		LocalDate today = LocalDate.now();

		Map<String, Long> stats = new LinkedHashMap<>();
		stats.put("totalAppointments", (long) appointments.size());
		stats.put("upcomingAppointments", countWhere(appointments,
			app -> isActive(app.getStatus()) && app.getDate() != null && !app.getDate().isBefore(today)));
		stats.put("activeAppointments", countWhere(appointments, app -> isActive(app.getStatus())));
		stats.put("completedAppointments", countWhere(appointments, app -> app.getStatus() == AppointmentStatus.COMPLETED));
		return stats;
	}

	public Map<String, Long> buildDoctorStats(String email) {
		List<Appointment> appointments = getDoctorAppointments(email);
		LocalDate today = LocalDate.now();

		Map<String, Long> stats = new LinkedHashMap<>();
		stats.put("totalAppointments", (long) appointments.size());
		stats.put("todayAppointments", countWhere(appointments, app -> today.equals(app.getDate())));
		stats.put("pendingAppointments", countWhere(appointments, app -> app.getStatus() == AppointmentStatus.REQUESTED));
		stats.put("completedAppointments", countWhere(appointments, app -> app.getStatus() == AppointmentStatus.COMPLETED));
		stats.put("highPriorityAppointments", countWhere(appointments, app -> equalsIgnoreCase(app.getPriority(), "Urgent")));
		return stats;
	}

	public Optional<Appointment> findNextPatientAppointment(String email) {
		LocalDate today = LocalDate.now();
		return getPatientAppointments(email).stream()
			.filter(app -> isActive(app.getStatus()) && app.getDate() != null && !app.getDate().isBefore(today))
			.findFirst();
	}

	public List<Appointment> getRecentPatientAppointments(String email) {
		List<Appointment> appointments = new ArrayList<>(getPatientAppointments(email));
		appointments.sort(Comparator.comparing(Appointment::getCreatedAt, Comparator.nullsLast(Comparator.reverseOrder())));
		return appointments.stream().limit(5).collect(Collectors.toList());
	}

	@Transactional
	public ActionResult createAppointment(Person patient, Appointment request) {
		if (patient == null) {
			return ActionResult.failure("Please sign in as a patient to continue.");
		}
		if (request == null || request.getDocId() == null || request.getDocId().isBlank()) {
			return ActionResult.failure("Select a doctor before booking.");
		}

		Optional<Doctor> doctorOptional = doctorRepository.findById(normalize(request.getDocId()));
		if (doctorOptional.isEmpty()) {
			return ActionResult.failure("The selected doctor is no longer available.");
		}

		Doctor doctor = doctorOptional.get();
		if (request.getDate() == null || request.getDate().isBefore(LocalDate.now())) {
			return ActionResult.failure("Choose a current or future appointment date.");
		}
		if (request.getTimeSlot() == null || request.getTimeSlot().isBlank()) {
			return ActionResult.failure("Choose an appointment time slot.");
		}
		if (!isDoctorAvailableOn(doctor, request.getDate())) {
			return ActionResult.failure("The doctor is not available on the selected day.");
		}

		String chosenMode = defaultText(request.getMode(), "In Person");
		if (!doctorSupportsMode(doctor, chosenMode)) {
			return ActionResult.failure("The selected consultation mode is not offered by this doctor.");
		}

		boolean slotTaken = appointmentRepository.existsByDocIdAndDateAndTimeSlotAndStatusIn(
			doctor.getEmail(),
			request.getDate(),
			request.getTimeSlot(),
			ACTIVE_STATUSES
		);
		if (slotTaken) {
			return ActionResult.failure("That time slot is already booked. Choose another one.");
		}

		Appointment appointment = new Appointment();
		appointment.setEmail(patient.getEmail());
		appointment.setPatientName(patient.getDisplayName());
		appointment.setDocId(doctor.getEmail());
		appointment.setDocName(doctor.getName());
		appointment.setDocSpecial(doctor.getSpecialization());
		appointment.setDate(request.getDate());
		appointment.setTimeSlot(request.getTimeSlot());
		appointment.setMode(chosenMode);
		appointment.setPriority(defaultText(request.getPriority(), "Routine"));
		appointment.setSymptoms(defaultText(request.getSymptoms(), "General consultation"));
		appointment.setStatus(AppointmentStatus.REQUESTED);
		appointmentRepository.save(appointment);

		return ActionResult.success("Appointment request sent successfully.");
	}

	@Transactional
	public ActionResult updateAppointmentStatus(String appId, AppointmentStatus status, String actorEmail, boolean doctorActor) {
		Optional<Appointment> appointmentOptional = appointmentRepository.findById(appId);
		if (appointmentOptional.isEmpty()) {
			return ActionResult.failure("Appointment not found.");
		}

		Appointment appointment = appointmentOptional.get();
		String normalizedActor = normalize(actorEmail);
		if (doctorActor) {
			if (!normalize(appointment.getDocId()).equals(normalizedActor)) {
				return ActionResult.failure("You can only manage your own appointments.");
			}
		} else if (!normalize(appointment.getEmail()).equals(normalizedActor)) {
			return ActionResult.failure("You can only manage your own appointments.");
		}

		if (appointment.getStatus() == AppointmentStatus.CANCELLED || appointment.getStatus() == AppointmentStatus.COMPLETED) {
			return ActionResult.failure("This appointment is already closed.");
		}
		if (!doctorActor && status != AppointmentStatus.CANCELLED) {
			return ActionResult.failure("Patients can only cancel appointments.");
		}
		if (status == AppointmentStatus.CONFIRMED && appointment.getStatus() != AppointmentStatus.REQUESTED) {
			return ActionResult.failure("Only requested appointments can be confirmed.");
		}
		if (status == AppointmentStatus.COMPLETED && appointment.getStatus() == AppointmentStatus.CANCELLED) {
			return ActionResult.failure("Cancelled appointments cannot be completed.");
		}

		appointment.setStatus(status);
		appointmentRepository.save(appointment);

		if (status == AppointmentStatus.CANCELLED) {
			return ActionResult.success("Appointment cancelled.");
		}
		if (status == AppointmentStatus.CONFIRMED) {
			return ActionResult.success("Appointment confirmed.");
		}
		if (status == AppointmentStatus.COMPLETED) {
			return ActionResult.success("Appointment marked as completed.");
		}
		return ActionResult.success("Appointment updated.");
	}

	public boolean hasDoctors() {
		return doctorRepository.count() > 0;
	}

	@Transactional
	public void seedDoctorsIfEmpty() {
		if (!personRepository.existsById("alex.carter@mednova.app")) {
			Person demoPatient = new Person();
			demoPatient.setEmail("alex.carter@mednova.app");
			demoPatient.setFullName("Alex Carter");
			demoPatient.setPhoneNumber("9876501234");
			demoPatient.setCity("Bengaluru");
			demoPatient.setPassword("patient123");
			registerPatient(demoPatient);
		}

		if (hasDoctors()) {
			return;
		}

		registerDoctor(buildDoctor(
			"dr.amelia@mednova.app",
			"Dr. Amelia Ross",
			"Cardiology",
			"MD, DM Cardiology",
			"Karnataka",
			"Bengaluru",
			"MedNova Heart Institute",
			12,
			BigDecimal.valueOf(1600),
			"Monday, Tuesday, Thursday, Saturday",
			"In-person, Virtual",
			"Interventional cardiologist focused on preventive diagnostics and long-term cardiac monitoring.",
			"doctor123"
		));
		registerDoctor(buildDoctor(
			"dr.riya@mednova.app",
			"Dr. Riya Menon",
			"Dermatology",
			"MD Dermatology",
			"Kerala",
			"Kochi",
			"Pulse Skin Studio",
			9,
			BigDecimal.valueOf(1100),
			"Monday, Wednesday, Friday",
			"In-person, Virtual",
			"Digital-first dermatologist with a focus on chronic skin conditions, tele-consults, and preventive routines.",
			"doctor123"
		));
		registerDoctor(buildDoctor(
			"dr.aarav@mednova.app",
			"Dr. Aarav Shah",
			"Orthopedics",
			"MS Orthopedics",
			"Maharashtra",
			"Mumbai",
			"Stride Motion Clinic",
			15,
			BigDecimal.valueOf(1800),
			"Tuesday, Wednesday, Thursday, Friday",
			"In-person, Hybrid Follow-up",
			"Sports injury and mobility specialist working across rehabilitation-led treatment plans.",
			"doctor123"
		));
		registerDoctor(buildDoctor(
			"dr.naina@mednova.app",
			"Dr. Naina Verma",
			"General Medicine",
			"MBBS, MD Internal Medicine",
			"Delhi",
			"New Delhi",
			"Cityline Medical Hub",
			11,
			BigDecimal.valueOf(900),
			"Monday, Tuesday, Wednesday, Thursday, Friday",
			"In-person, Virtual",
			"Primary care physician managing ongoing conditions, care coordination, and proactive wellness reviews.",
			"doctor123"
		));

		appointmentRepository.save(buildAppointment(
			"alex.carter@mednova.app",
			"Alex Carter",
			"dr.amelia@mednova.app",
			"Dr. Amelia Ross",
			"Cardiology",
			LocalDate.now().plusDays(1),
			"10:30 AM",
			"Virtual",
			"Priority",
			"Chest discomfort during intensive workouts.",
			AppointmentStatus.CONFIRMED
		));
		appointmentRepository.save(buildAppointment(
			"alex.carter@mednova.app",
			"Alex Carter",
			"dr.naina@mednova.app",
			"Dr. Naina Verma",
			"General Medicine",
			LocalDate.now().plusDays(4),
			"09:30 AM",
			"In-person",
			"Routine",
			"Quarterly wellness review and fatigue follow-up.",
			AppointmentStatus.REQUESTED
		));
		appointmentRepository.save(buildAppointment(
			"alex.carter@mednova.app",
			"Alex Carter",
			"dr.aarav@mednova.app",
			"Dr. Aarav Shah",
			"Orthopedics",
			LocalDate.now().minusDays(7),
			"02:00 PM",
			"Hybrid Follow-up",
			"Urgent",
			"Post-physiotherapy mobility reassessment.",
			AppointmentStatus.COMPLETED
		));
	}

	private Doctor buildDoctor(
		String email,
		String name,
		String specialization,
		String degree,
		String state,
		String city,
		String hospitalName,
		int yearsOfExperience,
		BigDecimal consultationFee,
		String availableDays,
		String consultationModes,
		String bio,
		String password
	) {
		Doctor doctor = new Doctor();
		doctor.setEmail(email);
		doctor.setName(name);
		doctor.setSpecialization(specialization);
		doctor.setDegree(degree);
		doctor.setState(state);
		doctor.setCity(city);
		doctor.setHospitalName(hospitalName);
		doctor.setYearsOfExperience(yearsOfExperience);
		doctor.setConsultationFee(consultationFee);
		doctor.setAvailableDays(availableDays);
		doctor.setConsultationModes(consultationModes);
		doctor.setBio(bio);
		doctor.setPassword(password);
		return doctor;
	}

	private Appointment buildAppointment(
		String patientEmail,
		String patientName,
		String doctorEmail,
		String doctorName,
		String specialization,
		LocalDate date,
		String timeSlot,
		String mode,
		String priority,
		String symptoms,
		AppointmentStatus status
	) {
		Appointment appointment = new Appointment();
		appointment.setEmail(patientEmail);
		appointment.setPatientName(patientName);
		appointment.setDocId(doctorEmail);
		appointment.setDocName(doctorName);
		appointment.setDocSpecial(specialization);
		appointment.setDate(date);
		appointment.setTimeSlot(timeSlot);
		appointment.setMode(mode);
		appointment.setPriority(priority);
		appointment.setSymptoms(symptoms);
		appointment.setStatus(status);
		return appointment;
	}

	private boolean isDoctorAvailableOn(Doctor doctor, LocalDate date) {
		String availableDays = defaultText(doctor.getAvailableDays(), "Monday, Tuesday, Wednesday, Thursday, Friday");
		List<String> normalizedDays = Arrays.stream(availableDays.split(","))
			.map(String::trim)
			.filter(value -> !value.isBlank())
			.map(value -> value.toLowerCase(Locale.ENGLISH))
			.collect(Collectors.toList());

		DayOfWeek dayOfWeek = date.getDayOfWeek();
		String longDay = dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH).toLowerCase(Locale.ENGLISH);
		String shortDay = dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).toLowerCase(Locale.ENGLISH);
		return normalizedDays.contains(longDay) || normalizedDays.contains(shortDay);
	}

	private boolean doctorSupportsMode(Doctor doctor, String mode) {
		String consultationModes = defaultText(doctor.getConsultationModes(), "In Person, Virtual");
		String normalizedMode = normalizeMode(mode);
		List<String> supportedModes = Arrays.stream(consultationModes.split(","))
			.map(String::trim)
			.map(this::normalizeMode)
			.collect(Collectors.toList());
		return supportedModes.contains(normalizedMode);
	}

	private long countWhere(Collection<Appointment> appointments, java.util.function.Predicate<Appointment> predicate) {
		return appointments.stream().filter(predicate).count();
	}

	private boolean isActive(AppointmentStatus status) {
		return ACTIVE_STATUSES.contains(status);
	}

	private boolean equalsIgnoreCase(String left, String right) {
		if (left == null || right == null) {
			return false;
		}
		return left.equalsIgnoreCase(right);
	}

	private String defaultText(String value, String fallback) {
		if (value == null || value.isBlank()) {
			return fallback;
		}
		return value.trim();
	}

	private String normalize(String value) {
		if (value == null) {
			return "";
		}
		return value.trim().toLowerCase(Locale.ENGLISH);
	}

	private String normalizeMode(String value) {
		return normalize(value).replaceAll("[^a-z]", "");
	}

	private String deriveNameFromEmail(String email) {
		if (email == null || !email.contains("@")) {
			return "Patient";
		}
		String base = email.substring(0, email.indexOf('@')).replace('.', ' ').replace('_', ' ').trim();
		if (base.isBlank()) {
			return "Patient";
		}
		return Arrays.stream(base.split("\\s+"))
			.map(part -> part.substring(0, 1).toUpperCase(Locale.ENGLISH) + part.substring(1))
			.collect(Collectors.joining(" "));
	}

	public static class ActionResult {

		private final boolean success;
		private final String message;

		private ActionResult(boolean success, String message) {
			this.success = success;
			this.message = message;
		}

		public static ActionResult success(String message) {
			return new ActionResult(true, message);
		}

		public static ActionResult failure(String message) {
			return new ActionResult(false, message);
		}

		public boolean isSuccess() {
			return success;
		}

		public String getMessage() {
			return message;
		}
	}
}
