package com.externship.appointment.Appointment_storage;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.externship.appointment.Doctor_storage.Doctor;
import com.externship.appointment.Person_storage.Person;

@Service
public class AppointmentService {

	private static final List<String> DEFAULT_TIME_SLOTS = Collections.unmodifiableList(Arrays.asList(
		"09:00 AM",
		"09:30 AM",
		"10:00 AM",
		"10:30 AM",
		"11:30 AM",
		"12:00 PM",
		"02:00 PM",
		"02:30 PM",
		"03:00 PM",
		"04:30 PM"
	));

	private static final List<String> MODE_OPTIONS = Collections.unmodifiableList(Arrays.asList(
		"In-person",
		"Virtual",
		"Hybrid Follow-up"
	));

	private static final List<String> PRIORITY_OPTIONS = Collections.unmodifiableList(Arrays.asList(
		"Routine",
		"Priority",
		"Urgent"
	));

	private final AppointmentRepository appointmentRepository;

	public AppointmentService(AppointmentRepository appointmentRepository) {
		this.appointmentRepository = appointmentRepository;
	}

	public List<String> getTimeSlots() {
		return DEFAULT_TIME_SLOTS;
	}

	public List<String> getModeOptions() {
		return MODE_OPTIONS;
	}

	public List<String> getPriorityOptions() {
		return PRIORITY_OPTIONS;
	}

	public List<Appointment> findPatientAppointments(String patientEmail) {
		return appointmentRepository.findAllByEmailOrderByDateAscTimeSlotAsc(patientEmail);
	}

	public List<Appointment> findDoctorAppointments(String doctorEmail) {
		return appointmentRepository.findByDocIdOrderByDateAscTimeSlotAsc(doctorEmail);
	}

	public Appointment bookAppointment(Person patient, Doctor doctor, Appointment request) {
		LocalDate requestedDate = request.getDate();
		if (requestedDate == null) {
			throw new IllegalArgumentException("Select an appointment date.");
		}
		if (requestedDate.isBefore(LocalDate.now())) {
			throw new IllegalArgumentException("Appointments can only be booked from today onward.");
		}
		if (!isDoctorAvailableOn(doctor, requestedDate)) {
			throw new IllegalArgumentException("The doctor is not available on the selected day.");
		}

		String timeSlot = normalizeOption(request.getTimeSlot(), DEFAULT_TIME_SLOTS, DEFAULT_TIME_SLOTS.get(0));
		String chosenMode = normalizeOption(request.getMode(), MODE_OPTIONS, MODE_OPTIONS.get(0));
		if (!doctorSupportsMode(doctor, chosenMode)) {
			throw new IllegalArgumentException("The selected consultation mode is not offered by this doctor.");
		}
		boolean slotTaken = appointmentRepository.existsByDocIdAndDateAndTimeSlotAndStatusIn(
			doctor.getEmail(),
			requestedDate,
			timeSlot,
			Arrays.asList(AppointmentStatus.REQUESTED, AppointmentStatus.CONFIRMED)
		);
		if (slotTaken) {
			throw new IllegalArgumentException("That slot is already reserved. Choose a different time.");
		}

		Appointment appointment = new Appointment();
		appointment.setEmail(patient.getEmail());
		appointment.setPatientName(patient.getDisplayName());
		appointment.setDocId(doctor.getEmail());
		appointment.setDocName(doctor.getName());
		appointment.setDocSpecial(doctor.getSpecialization());
		appointment.setDate(requestedDate);
		appointment.setTimeSlot(timeSlot);
		appointment.setMode(chosenMode);
		appointment.setPriority(normalizeOption(request.getPriority(), PRIORITY_OPTIONS, PRIORITY_OPTIONS.get(0)));
		appointment.setSymptoms(cleanText(request.getSymptoms(), 700));
		appointment.setStatus(AppointmentStatus.REQUESTED);
		return appointmentRepository.save(appointment);
	}

	public void cancelForPatient(String appointmentId, String patientEmail) {
		Appointment appointment = appointmentRepository.findById(appointmentId)
			.orElseThrow(() -> new IllegalArgumentException("Appointment not found."));
		if (!appointment.getEmail().equalsIgnoreCase(patientEmail)) {
			throw new IllegalArgumentException("You can only cancel your own appointments.");
		}
		if (appointment.getStatus() == AppointmentStatus.COMPLETED) {
			throw new IllegalArgumentException("Completed appointments cannot be cancelled.");
		}
		appointment.setStatus(AppointmentStatus.CANCELLED);
		appointmentRepository.save(appointment);
	}

	public void cancelForDoctor(String appointmentId, String doctorEmail) {
		Appointment appointment = appointmentRepository.findById(appointmentId)
			.orElseThrow(() -> new IllegalArgumentException("Appointment not found."));
		if (!appointment.getDocId().equalsIgnoreCase(doctorEmail)) {
			throw new IllegalArgumentException("You can only manage appointments assigned to you.");
		}
		if (appointment.getStatus() == AppointmentStatus.COMPLETED) {
			throw new IllegalArgumentException("Completed appointments cannot be cancelled.");
		}
		appointment.setStatus(AppointmentStatus.CANCELLED);
		appointmentRepository.save(appointment);
	}

	public void updateByDoctor(String appointmentId, AppointmentStatus status, String doctorEmail) {
		Appointment appointment = appointmentRepository.findById(appointmentId)
			.orElseThrow(() -> new IllegalArgumentException("Appointment not found."));
		if (!appointment.getDocId().equalsIgnoreCase(doctorEmail)) {
			throw new IllegalArgumentException("You can only manage appointments assigned to you.");
		}
		if (appointment.getStatus() == AppointmentStatus.CANCELLED) {
			throw new IllegalArgumentException("Cancelled appointments cannot be updated.");
		}
		if (appointment.getStatus() == AppointmentStatus.COMPLETED) {
			throw new IllegalArgumentException("Completed appointments are locked.");
		}
		appointment.setStatus(status);
		appointmentRepository.save(appointment);
	}

	public Optional<Appointment> findNextUpcoming(List<Appointment> appointments) {
		return appointments.stream()
			.filter(appointment -> appointment.getDate() != null)
			.filter(appointment -> !appointment.getDate().isBefore(LocalDate.now()))
			.filter(appointment -> appointment.getStatus() != AppointmentStatus.CANCELLED)
			.filter(appointment -> appointment.getStatus() != AppointmentStatus.COMPLETED)
			.min(Comparator.comparing(Appointment::getDate).thenComparing(Appointment::getTimeSlot, Comparator.nullsLast(String::compareTo)));
	}

	public List<Appointment> findRecentAppointments(List<Appointment> appointments, int limit) {
		return appointments.stream()
			.sorted(Comparator.comparing(Appointment::getCreatedAt, Comparator.nullsLast(Comparator.reverseOrder()))
				.thenComparing(Appointment::getDate, Comparator.nullsLast(Comparator.reverseOrder())))
			.limit(limit)
			.collect(Collectors.toList());
	}

	public Map<String, Long> buildPatientDashboardStats(List<Appointment> appointments) {
		Map<String, Long> stats = new LinkedHashMap<>();
		stats.put("totalAppointments", (long) appointments.size());
		stats.put("upcomingAppointments", appointments.stream()
			.filter(appointment -> appointment.getDate() != null)
			.filter(appointment -> !appointment.getDate().isBefore(LocalDate.now()))
			.filter(appointment -> appointment.getStatus() != AppointmentStatus.CANCELLED)
			.filter(appointment -> appointment.getStatus() != AppointmentStatus.COMPLETED)
			.count());
		stats.put("confirmedAppointments", appointments.stream()
			.filter(appointment -> appointment.getStatus() == AppointmentStatus.CONFIRMED)
			.count());
		stats.put("virtualAppointments", appointments.stream()
			.filter(appointment -> "virtual".equalsIgnoreCase(appointment.getMode()))
			.count());
		return stats;
	}

	public Map<String, Long> buildPatientAppointmentStats(List<Appointment> appointments) {
		Map<String, Long> stats = new LinkedHashMap<>();
		stats.put("totalAppointments", (long) appointments.size());
		stats.put("upcomingAppointments", appointments.stream()
			.filter(appointment -> appointment.getDate() != null)
			.filter(appointment -> !appointment.getDate().isBefore(LocalDate.now()))
			.filter(appointment -> appointment.getStatus() != AppointmentStatus.CANCELLED)
			.filter(appointment -> appointment.getStatus() != AppointmentStatus.COMPLETED)
			.count());
		stats.put("activeAppointments", appointments.stream()
			.filter(appointment -> appointment.getStatus() == AppointmentStatus.REQUESTED
				|| appointment.getStatus() == AppointmentStatus.CONFIRMED)
			.count());
		stats.put("completedAppointments", appointments.stream()
			.filter(appointment -> appointment.getStatus() == AppointmentStatus.COMPLETED)
			.count());
		return stats;
	}

	public Map<String, Long> buildDoctorDashboardStats(List<Appointment> appointments) {
		Map<String, Long> stats = new LinkedHashMap<>();
		stats.put("totalAppointments", (long) appointments.size());
		stats.put("todayAppointments", appointments.stream()
			.filter(appointment -> LocalDate.now().equals(appointment.getDate()))
			.count());
		stats.put("pendingAppointments", appointments.stream()
			.filter(appointment -> appointment.getStatus() == AppointmentStatus.REQUESTED)
			.count());
		stats.put("completedAppointments", appointments.stream()
			.filter(appointment -> appointment.getStatus() == AppointmentStatus.COMPLETED)
			.count());
		stats.put("highPriorityAppointments", appointments.stream()
			.filter(appointment -> "urgent".equalsIgnoreCase(appointment.getPriority())
				|| "priority".equalsIgnoreCase(appointment.getPriority()))
			.count());
		return stats;
	}

	private String normalizeOption(String rawValue, List<String> options, String fallback) {
		if (rawValue == null || rawValue.isBlank()) {
			return fallback;
		}
		String normalized = rawValue.trim();
		for (String option : options) {
			if (option.equalsIgnoreCase(normalized)) {
				return option;
			}
		}
		return fallback;
	}

	private boolean doctorSupportsMode(Doctor doctor, String mode) {
		String consultationModes = cleanText(doctor.getConsultationModes(), 200);
		if (consultationModes.isBlank()) {
			return true;
		}
		return Arrays.stream(consultationModes.split(","))
			.map(String::trim)
			.filter(value -> !value.isBlank())
			.anyMatch(value -> value.equalsIgnoreCase(mode));
	}

	private boolean isDoctorAvailableOn(Doctor doctor, LocalDate date) {
		String availableDays = cleanText(doctor.getAvailableDays(), 200);
		if (availableDays.isBlank()) {
			return true;
		}
		DayOfWeek dayOfWeek = date.getDayOfWeek();
		String fullName = dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH);
		String shortName = dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
		return Arrays.stream(availableDays.split(","))
			.map(String::trim)
			.filter(value -> !value.isBlank())
			.anyMatch(value -> value.equalsIgnoreCase(fullName) || value.equalsIgnoreCase(shortName));
	}

	private String cleanText(String value, int maxLength) {
		if (value == null) {
			return "";
		}
		String normalized = value.trim().replaceAll("\\s+", " ");
		if (normalized.length() <= maxLength) {
			return normalized;
		}
		return normalized.substring(0, maxLength);
	}
}
