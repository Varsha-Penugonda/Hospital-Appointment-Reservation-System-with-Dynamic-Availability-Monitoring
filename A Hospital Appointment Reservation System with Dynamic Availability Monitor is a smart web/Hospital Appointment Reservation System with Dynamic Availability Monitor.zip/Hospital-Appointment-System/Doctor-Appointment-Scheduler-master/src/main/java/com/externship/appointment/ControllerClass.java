package com.externship.appointment;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.externship.appointment.Appointment_storage.Appointment;
import com.externship.appointment.Appointment_storage.AppointmentService;
import com.externship.appointment.Appointment_storage.AppointmentStatus;
import com.externship.appointment.Doctor_storage.Doctor;
import com.externship.appointment.Doctor_storage.DoctorRepository;
import com.externship.appointment.Person_storage.Person;
import com.externship.appointment.Person_storage.PersonRepository;

@Controller
public class ControllerClass {

	private static final String DEMO_PATIENT_EMAIL = "alex.carter@mednova.app";
	private static final String DEMO_PATIENT_PASSWORD = "patient123";
	private static final String DEMO_DOCTOR_EMAIL = "dr.amelia@mednova.app";
	private static final String DEMO_DOCTOR_PASSWORD = "doctor123";

	private final PersonRepository personRepository;
	private final DoctorRepository doctorRepository;
	private final AppointmentService appointmentService;

	public ControllerClass(
		PersonRepository personRepository,
		DoctorRepository doctorRepository,
		AppointmentService appointmentService
	) {
		this.personRepository = personRepository;
		this.doctorRepository = doctorRepository;
		this.appointmentService = appointmentService;
	}

	@GetMapping("/")
	public ModelAndView landing() {
		List<Doctor> doctors = doctorRepository.findAllByOrderBySpecializationAscNameAsc();
		ModelAndView mav = new ModelAndView("start");
		mav.addObject("featuredDoctors", doctors.stream().limit(4).collect(Collectors.toList()));
		mav.addObject("doctorCount", doctors.size());
		mav.addObject("specializationCount", doctors.stream()
			.map(Doctor::getSpecialization)
			.filter(Objects::nonNull)
			.filter(value -> !value.isBlank())
			.distinct()
			.count());
		mav.addObject("modeOptions", appointmentService.getModeOptions());
		return mav;
	}

	@GetMapping("/patlog")
	public ModelAndView patlog() {
		ModelAndView mav = new ModelAndView("index");
		mav.addObject("demoEmail", DEMO_PATIENT_EMAIL);
		mav.addObject("demoPassword", DEMO_PATIENT_PASSWORD);
		return mav;
	}

	@GetMapping("/doclog")
	public ModelAndView doclog() {
		ModelAndView mav = new ModelAndView("doclog");
		mav.addObject("demoEmail", DEMO_DOCTOR_EMAIL);
		mav.addObject("demoPassword", DEMO_DOCTOR_PASSWORD);
		return mav;
	}

	@GetMapping("/register")
	public ModelAndView register() {
		return new ModelAndView("register");
	}

	@GetMapping("/registerdoc")
	public ModelAndView registerdoc() {
		ModelAndView mav = new ModelAndView("registerdoc");
		mav.addObject("modeOptions", appointmentService.getModeOptions());
		return mav;
	}

	@GetMapping("/fail_login")
	public ModelAndView failLogin() {
		ModelAndView mav = new ModelAndView("fail_login");
		mav.addObject("error", "The email and password combination was not recognized.");
		return mav;
	}

	@PostMapping("/registered")
	public String registered(Person person, RedirectAttributes redirectAttributes) {
		try {
			personRepository.save(preparePerson(person));
			redirectAttributes.addFlashAttribute("message", "Patient account created. Sign in to start booking.");
			return "redirect:/patlog";
		} catch (IllegalArgumentException ex) {
			redirectAttributes.addFlashAttribute("error", ex.getMessage());
			return "redirect:/register";
		}
	}

	@PostMapping("/registereddoc")
	public String registereddoc(Doctor doctor, RedirectAttributes redirectAttributes) {
		try {
			doctorRepository.save(prepareDoctor(doctor));
			redirectAttributes.addFlashAttribute("message", "Doctor profile created. Sign in to manage your schedule.");
			return "redirect:/doclog";
		} catch (IllegalArgumentException ex) {
			redirectAttributes.addFlashAttribute("error", ex.getMessage());
			return "redirect:/registerdoc";
		}
	}

	@PostMapping("/authenticate")
	public String authenticate(Person loginRequest, HttpSession session, RedirectAttributes redirectAttributes) {
		Optional<Person> person = personRepository.findById(normalizeEmail(loginRequest.getEmail()));
		if (person.isPresent() && Objects.equals(person.get().getPassword(), loginRequest.getPassword())) {
			session.setAttribute("person", person.get().getEmail());
			session.setAttribute("personName", person.get().getDisplayName());
			session.removeAttribute("doctor");
			session.removeAttribute("doctorName");
			return "redirect:/home";
		}
		redirectAttributes.addFlashAttribute("error", "Invalid patient credentials.");
		return "redirect:/fail_login";
	}

	@PostMapping("/authenticatedoc")
	public String authenticatedoc(Doctor loginRequest, HttpSession session, RedirectAttributes redirectAttributes) {
		Optional<Doctor> doctor = doctorRepository.findById(normalizeEmail(loginRequest.getEmail()));
		if (doctor.isPresent() && Objects.equals(doctor.get().getPassword(), loginRequest.getPassword())) {
			session.setAttribute("doctor", doctor.get().getEmail());
			session.setAttribute("doctorName", doctor.get().getName());
			session.removeAttribute("person");
			session.removeAttribute("personName");
			return "redirect:/patientlist";
		}
		redirectAttributes.addFlashAttribute("error", "Invalid doctor credentials.");
		return "redirect:/fail_login";
	}

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

	@GetMapping("/home")
	public ModelAndView home(HttpSession session) {
		Person patient = currentPatient(session);
		if (patient == null) {
			return new ModelAndView("redirect:/patlog");
		}

		List<Appointment> appointments = appointmentService.findPatientAppointments(patient.getEmail());
		List<Doctor> featuredDoctors = doctorRepository.findAllByOrderBySpecializationAscNameAsc().stream()
			.sorted(Comparator.comparing(Doctor::getYearsOfExperience, Comparator.nullsLast(Comparator.reverseOrder()))
				.thenComparing(Doctor::getName, Comparator.nullsLast(String::compareToIgnoreCase)))
			.limit(4)
			.collect(Collectors.toList());

		ModelAndView mav = new ModelAndView("home");
		mav.addObject("patient", patient);
		mav.addObject("email", patient.getEmail());
		mav.addObject("stats", appointmentService.buildPatientDashboardStats(appointments));
		mav.addObject("nextAppointment", appointmentService.findNextUpcoming(appointments).orElse(null));
		mav.addObject("recentAppointments", appointmentService.findRecentAppointments(appointments, 5));
		mav.addObject("featuredDoctors", featuredDoctors);
		return mav;
	}

	@GetMapping("/docdetails")
	public ModelAndView docdetails(HttpSession session) {
		Person patient = currentPatient(session);
		if (patient == null) {
			return new ModelAndView("redirect:/patlog");
		}

		List<Doctor> doctors = doctorRepository.findAllByOrderBySpecializationAscNameAsc();
		ModelAndView mav = new ModelAndView("doctorlist");
		mav.addObject("patient", patient);
		mav.addObject("doctor", doctors);
		mav.addObject("email", patient.getEmail());
		mav.addObject("specializations", doctors.stream()
			.map(Doctor::getSpecialization)
			.filter(Objects::nonNull)
			.filter(value -> !value.isBlank())
			.distinct()
			.collect(Collectors.toList()));
		mav.addObject("cities", doctors.stream()
			.map(Doctor::getCity)
			.filter(Objects::nonNull)
			.filter(value -> !value.isBlank())
			.distinct()
			.sorted(String::compareToIgnoreCase)
			.collect(Collectors.toList()));
		mav.addObject("timeSlots", appointmentService.getTimeSlots());
		mav.addObject("modeOptions", appointmentService.getModeOptions());
		mav.addObject("priorityOptions", appointmentService.getPriorityOptions());
		mav.addObject("today", LocalDate.now());
		return mav;
	}

	@PostMapping("/assignment")
	public String assignment(Appointment appointment, HttpSession session, RedirectAttributes redirectAttributes) {
		Person patient = currentPatient(session);
		if (patient == null) {
			return "redirect:/patlog";
		}

		try {
			Doctor doctor = doctorRepository.findById(normalizeEmail(appointment.getDocId()))
				.orElseThrow(() -> new IllegalArgumentException("The selected doctor is unavailable."));
			appointmentService.bookAppointment(patient, doctor, appointment);
			redirectAttributes.addFlashAttribute("message", "Appointment request sent successfully.");
			return "redirect:/userdetails";
		} catch (IllegalArgumentException ex) {
			redirectAttributes.addFlashAttribute("error", ex.getMessage());
			return "redirect:/docdetails";
		}
	}

	@GetMapping("/userdetails")
	public ModelAndView userdetails(HttpSession session) {
		Person patient = currentPatient(session);
		if (patient == null) {
			return new ModelAndView("redirect:/patlog");
		}

		List<Appointment> appointments = appointmentService.findPatientAppointments(patient.getEmail());
		ModelAndView mav = new ModelAndView("appointed");
		mav.addObject("patient", patient);
		mav.addObject("appointments", appointments);
		mav.addObject("email", patient.getEmail());
		mav.addObject("stats", appointmentService.buildPatientAppointmentStats(appointments));
		return mav;
	}

	@GetMapping("/patientlist")
	public ModelAndView patientlist(HttpSession session) {
		Doctor doctor = currentDoctor(session);
		if (doctor == null) {
			return new ModelAndView("redirect:/doclog");
		}

		List<Appointment> appointments = appointmentService.findDoctorAppointments(doctor.getEmail());
		ModelAndView mav = new ModelAndView("appointedDoc");
		mav.addObject("doctorProfile", doctor);
		mav.addObject("appointments", appointments);
		mav.addObject("email", doctor.getEmail());
		mav.addObject("stats", appointmentService.buildDoctorDashboardStats(appointments));
		return mav;
	}

	@PostMapping("/cancel")
	public String cancel(@RequestParam("appId") String appointmentId, HttpSession session, RedirectAttributes redirectAttributes) {
		Person patient = currentPatient(session);
		Doctor doctor = currentDoctor(session);
		try {
			if (patient != null) {
				appointmentService.cancelForPatient(appointmentId, patient.getEmail());
				redirectAttributes.addFlashAttribute("message", "Appointment cancelled.");
				return "redirect:/userdetails";
			}
			if (doctor != null) {
				appointmentService.cancelForDoctor(appointmentId, doctor.getEmail());
				redirectAttributes.addFlashAttribute("message", "Appointment cancelled.");
				return "redirect:/patientlist";
			}
			return "redirect:/";
		} catch (IllegalArgumentException ex) {
			redirectAttributes.addFlashAttribute("error", ex.getMessage());
			return patient != null ? "redirect:/userdetails" : "redirect:/patientlist";
		}
	}

	@PostMapping("/appointment/status")
	public String updateAppointmentStatus(
		@RequestParam("appId") String appointmentId,
		@RequestParam("status") String status,
		HttpSession session,
		RedirectAttributes redirectAttributes
	) {
		Doctor doctor = currentDoctor(session);
		if (doctor == null) {
			return "redirect:/doclog";
		}

		try {
			appointmentService.updateByDoctor(appointmentId, AppointmentStatus.from(status), doctor.getEmail());
			redirectAttributes.addFlashAttribute("message", "Appointment status updated.");
		} catch (IllegalArgumentException ex) {
			redirectAttributes.addFlashAttribute("error", ex.getMessage());
		}
		return "redirect:/patientlist";
	}

	private Person currentPatient(HttpSession session) {
		Object email = session.getAttribute("person");
		if (!(email instanceof String)) {
			return null;
		}
		return personRepository.findById((String) email).orElse(null);
	}

	private Doctor currentDoctor(HttpSession session) {
		Object email = session.getAttribute("doctor");
		if (!(email instanceof String)) {
			return null;
		}
		return doctorRepository.findById((String) email).orElse(null);
	}

	private Person preparePerson(Person person) {
		String email = normalizeEmail(person.getEmail());
		if (email.isBlank()) {
			throw new IllegalArgumentException("Email is required.");
		}
		if (personRepository.existsById(email)) {
			throw new IllegalArgumentException("A patient account with this email already exists.");
		}
		if (person.getPassword() == null || person.getPassword().isBlank()) {
			throw new IllegalArgumentException("Password is required.");
		}
		person.setEmail(email);
		person.setFullName(defaultIfBlank(person.getFullName(), deriveName(email)));
		person.setPhoneNumber(defaultIfBlank(person.getPhoneNumber(), "Not provided"));
		person.setCity(defaultIfBlank(person.getCity(), "Remote"));
		return person;
	}

	private Doctor prepareDoctor(Doctor doctor) {
		String email = normalizeEmail(doctor.getEmail());
		if (email.isBlank()) {
			throw new IllegalArgumentException("Email is required.");
		}
		if (doctorRepository.existsById(email)) {
			throw new IllegalArgumentException("A doctor account with this email already exists.");
		}
		if (doctor.getPassword() == null || doctor.getPassword().isBlank()) {
			throw new IllegalArgumentException("Password is required.");
		}
		doctor.setEmail(email);
		doctor.setName(defaultIfBlank(doctor.getName(), deriveName(email)));
		doctor.setSpecialization(defaultIfBlank(doctor.getSpecialization(), "General Medicine"));
		doctor.setDegree(defaultIfBlank(doctor.getDegree(), "MBBS"));
		doctor.setState(defaultIfBlank(doctor.getState(), "Available Nationwide"));
		doctor.setCity(defaultIfBlank(doctor.getCity(), "Remote"));
		doctor.setHospitalName(defaultIfBlank(doctor.getHospitalName(), "MedNova Care Center"));
		doctor.setYearsOfExperience(doctor.getYearsOfExperience() == null ? 8 : doctor.getYearsOfExperience());
		doctor.setConsultationFee(doctor.getConsultationFee() == null ? BigDecimal.valueOf(1200) : doctor.getConsultationFee());
		doctor.setAvailableDays(defaultIfBlank(doctor.getAvailableDays(), "Mon, Tue, Wed, Thu, Fri"));
		doctor.setConsultationModes(defaultIfBlank(doctor.getConsultationModes(), "In-person, Virtual"));
		doctor.setBio(defaultIfBlank(
			doctor.getBio(),
			"Experienced clinician focused on patient-first, digitally enabled care delivery."
		));
		return doctor;
	}

	private String normalizeEmail(String value) {
		return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
	}

	private String defaultIfBlank(String value, String fallback) {
		if (value == null || value.isBlank()) {
			return fallback;
		}
		return value.trim();
	}

	private String deriveName(String email) {
		if (email == null || email.isBlank()) {
			return "New User";
		}
		String localPart = email.split("@")[0].replace('.', ' ').replace('_', ' ').trim();
		if (localPart.isBlank()) {
			return "New User";
		}
		return Arrays.stream(localPart.split("\\s+"))
			.filter(part -> !part.isBlank())
			.map(part -> part.substring(0, 1).toUpperCase(Locale.ROOT) + part.substring(1).toLowerCase(Locale.ROOT))
			.collect(Collectors.joining(" "));
	}
}
