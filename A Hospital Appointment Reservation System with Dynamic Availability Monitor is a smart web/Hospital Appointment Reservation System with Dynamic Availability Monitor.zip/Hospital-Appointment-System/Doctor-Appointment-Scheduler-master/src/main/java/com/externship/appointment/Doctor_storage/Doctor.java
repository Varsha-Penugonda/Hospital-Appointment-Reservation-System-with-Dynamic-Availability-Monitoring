package com.externship.appointment.Doctor_storage;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "doctor")
public class Doctor {

	@Id
	private String email;

	private String name;

	private String specialization;

	private String degree;

	private String state;

	private String city;

	private String hospitalName;

	private Integer yearsOfExperience;

	private BigDecimal consultationFee;

	private String availableDays;

	private String consultationModes;

	@Column(length = 1600)
	private String bio;

	private String password;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public Integer getYearsOfExperience() {
		return yearsOfExperience;
	}

	public void setYearsOfExperience(Integer yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}

	public BigDecimal getConsultationFee() {
		return consultationFee;
	}

	public void setConsultationFee(BigDecimal consultationFee) {
		this.consultationFee = consultationFee;
	}

	public String getAvailableDays() {
		return availableDays;
	}

	public void setAvailableDays(String availableDays) {
		this.availableDays = availableDays;
	}

	public String getConsultationModes() {
		return consultationModes;
	}

	public void setConsultationModes(String consultationModes) {
		this.consultationModes = consultationModes;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Transient
	public String getDisplayFee() {
		return consultationFee == null ? "TBD" : consultationFee.toPlainString();
	}

	@Transient
	public String getDisplayLocation() {
		if (city == null || city.isBlank()) {
			return state == null ? "" : state;
		}
		if (state == null || state.isBlank()) {
			return city;
		}
		return city + ", " + state;
	}
}
