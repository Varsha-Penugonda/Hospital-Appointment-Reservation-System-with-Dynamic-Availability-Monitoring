package com.externship.appointment.Appointment_storage;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AppointmentRepository extends JpaRepository<Appointment, String> {

	List<Appointment> findAllByEmailOrderByDateAscTimeSlotAsc(String email);

	List<Appointment> findByDocIdOrderByDateAscTimeSlotAsc(String docId);

	boolean existsByDocIdAndDateAndTimeSlotAndStatusIn(
		String docId,
		LocalDate date,
		String timeSlot,
		Collection<AppointmentStatus> statuses
	);
}
