document.addEventListener("DOMContentLoaded", () => {
	const directory = document.querySelector("[data-doctor-directory]");
	if (!directory) {
		return;
	}

	const cards = Array.from(directory.querySelectorAll("[data-doctor-card]"));
	const search = document.querySelector("[data-filter-search]");
	const specialization = document.querySelector("[data-filter-specialization]");
	const city = document.querySelector("[data-filter-city]");
	const mode = document.querySelector("[data-filter-mode]");
	const selectedSummary = document.querySelector("[data-selected-doctor]");
	const doctorIdInput = document.querySelector("[data-booking-doctor-id]");
	const doctorNameInput = document.querySelector("[data-booking-doctor-name]");
	const doctorSpecialInput = document.querySelector("[data-booking-doctor-special]");
	const modeField = document.querySelector("[data-booking-mode]");

	const applyFilters = () => {
		const term = (search?.value || "").trim().toLowerCase();
		const selectedSpecialization = (specialization?.value || "").trim().toLowerCase();
		const selectedCity = (city?.value || "").trim().toLowerCase();
		const selectedMode = (mode?.value || "").trim().toLowerCase();

		cards.forEach((card) => {
			const matchesTerm =
				!term ||
				(card.dataset.name || "").toLowerCase().includes(term) ||
				(card.dataset.specialization || "").toLowerCase().includes(term) ||
				(card.dataset.hospital || "").toLowerCase().includes(term);
			const matchesSpecialization =
				!selectedSpecialization ||
				(card.dataset.specialization || "").toLowerCase() === selectedSpecialization;
			const matchesCity =
				!selectedCity ||
				(card.dataset.city || "").toLowerCase() === selectedCity;
			const matchesMode =
				!selectedMode ||
				(card.dataset.modes || "").toLowerCase().replace(/[\s-]+/g, "").includes(selectedMode.replace(/[\s-]+/g, ""));

			card.classList.toggle("hidden", !(matchesTerm && matchesSpecialization && matchesCity && matchesMode));
		});
	};

	const selectDoctor = (card) => {
		cards.forEach((entry) => entry.classList.remove("is-selected"));
		card.classList.add("is-selected");

		if (doctorIdInput) {
			doctorIdInput.value = card.dataset.id || "";
		}
		if (doctorNameInput) {
			doctorNameInput.value = card.dataset.name || "";
		}
		if (doctorSpecialInput) {
			doctorSpecialInput.value = card.dataset.specialization || "";
		}
		if (modeField) {
			const options = Array.from(modeField.options);
			const supportedModes = (card.dataset.modes || "").toLowerCase().replace(/[\s-]+/g, "");
			const preferred = options.find((option) =>
				supportedModes.includes(option.value.toLowerCase().replace(/[\s-]+/g, ""))
			);
			if (preferred) {
				modeField.value = preferred.value;
			}
		}
		if (selectedSummary) {
			selectedSummary.innerHTML = `
				<strong>${card.dataset.name || "Doctor selected"}</strong>
				<span>${card.dataset.specialization || ""}</span>
				<p>${card.dataset.hospital || ""} • ${card.dataset.city || ""}</p>
				<div class="tag-row">
					<span class="tag">${card.dataset.modes || "Consultation modes unavailable"}</span>
					<span class="pill">${card.dataset.days || "Schedule on request"}</span>
				</div>
			`;
		}
	};

	[search, specialization, city, mode].forEach((field) => {
		field?.addEventListener("input", applyFilters);
		field?.addEventListener("change", applyFilters);
	});

	cards.forEach((card) => {
		card.querySelector("[data-select-doctor]")?.addEventListener("click", () => selectDoctor(card));
	});

	applyFilters();
	if (cards.length > 0) {
		selectDoctor(cards[0]);
	}
});
