package com.externship.appointment;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Arrays;
import java.util.Locale;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.externship.appointment.Appointment_storage.Appointment;
import com.externship.appointment.Appointment_storage.AppointmentRepository;
import com.externship.appointment.Appointment_storage.AppointmentStatus;
import com.externship.appointment.Doctor_storage.Doctor;
import com.externship.appointment.Person_storage.Person;
import com.externship.appointment.Person_storage.PersonRepository;
import com.externship.appointment.service.PortalService;
import com.externship.appointment.service.PortalService.ActionResult;

@SpringBootTest
class AppointmentApplicationTests {

	@Autowired
	private PortalService portalService;

	@Autowired
	private AppointmentRepository appointmentRepository;

	@Autowired
	private PersonRepository personRepository;

	@BeforeEach
	void setup() {
		appointmentRepository.deleteAll();
		personRepository.deleteAll();
	}

	@Test
	void contextLoads() {
	}

	@Test
	void preventsDoubleBookingForActiveAppointments() {
		Doctor doctor = portalService.getDoctors().get(0);
		LocalDate appointmentDate = nextAvailableDate(doctor);

		Person firstPatient = registerPatient("patient.one@example.com", "Patient One");
		Person secondPatient = registerPatient("patient.two@example.com", "Patient Two");

		Appointment firstRequest = new Appointment();
		firstRequest.setDocId(doctor.getEmail());
		firstRequest.setDate(appointmentDate);
		firstRequest.setTimeSlot("10:00 AM");
		firstRequest.setMode("Virtual");
		firstRequest.setPriority("Routine");

		ActionResult firstBooking = portalService.createAppointment(firstPatient, firstRequest);
		assertThat(firstBooking.isSuccess()).isTrue();

		Appointment secondRequest = new Appointment();
		secondRequest.setDocId(doctor.getEmail());
		secondRequest.setDate(appointmentDate);
		secondRequest.setTimeSlot("10:00 AM");
		secondRequest.setMode("Virtual");
		secondRequest.setPriority("Urgent");

		ActionResult secondBooking = portalService.createAppointment(secondPatient, secondRequest);
		assertThat(secondBooking.isSuccess()).isFalse();
		assertThat(appointmentRepository.findAll()).hasSize(1);
	}

	@Test
	void doctorCanConfirmAndCompleteAppointment() {
		Doctor doctor = portalService.getDoctors().get(0);
		LocalDate appointmentDate = nextAvailableDate(doctor);
		Person patient = registerPatient("patient.workflow@example.com", "Workflow Patient");

		Appointment request = new Appointment();
		request.setDocId(doctor.getEmail());
		request.setDate(appointmentDate);
		request.setTimeSlot("11:00 AM");
		request.setMode("In Person");
		request.setPriority("Priority");

		ActionResult booking = portalService.createAppointment(patient, request);
		assertThat(booking.isSuccess()).isTrue();

		Appointment savedAppointment = appointmentRepository.findAll().get(0);

		ActionResult confirmed = portalService.updateAppointmentStatus(
			savedAppointment.getAppId(),
			AppointmentStatus.CONFIRMED,
			doctor.getEmail(),
			true
		);
		assertThat(confirmed.isSuccess()).isTrue();

		ActionResult completed = portalService.updateAppointmentStatus(
			savedAppointment.getAppId(),
			AppointmentStatus.COMPLETED,
			doctor.getEmail(),
			true
		);
		assertThat(completed.isSuccess()).isTrue();

		Appointment updatedAppointment = appointmentRepository.findById(savedAppointment.getAppId()).orElseThrow();
		assertThat(updatedAppointment.getStatus()).isEqualTo(AppointmentStatus.COMPLETED);
	}

	private Person registerPatient(String email, String name) {
		Person person = new Person();
		person.setEmail(email);
		person.setFullName(name);
		person.setPhoneNumber("9876543210");
		person.setCity("Bengaluru");
		person.setPassword("patient123");
		return portalService.registerPatient(person);
	}

	private LocalDate nextAvailableDate(Doctor doctor) {
		for (int offset = 1; offset <= 14; offset++) {
			LocalDate date = LocalDate.now().plusDays(offset);
			String fullDayName = date.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
			String shortDayName = date.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
			boolean matches = Arrays.stream(doctor.getAvailableDays().split(","))
				.map(String::trim)
				.anyMatch(day -> day.equalsIgnoreCase(fullDayName) || day.equalsIgnoreCase(shortDayName));
			if (matches) {
				return date;
			}
		}
		return LocalDate.now().plusDays(1);
	}
}
